import os
import time
import cv2
import numpy as np
import tensorflow as tf
from tensorflow.keras.preprocessing.image import ImageDataGenerator

start_time = time.time()

# Set training and validation directories
train_dir = "Replace/with/traing/images/folder"
validation_dir = "Replace/with/validation/images/folder"

# Set image dimensions and batch size
img_height, img_width = 128, 128
batch_size = 32

# Create an ImageDataGenerator for training and validation sets
train_datagen = ImageDataGenerator(rescale=1./255)
validation_datagen = ImageDataGenerator(rescale=1./255)

# Load images from the training set
train_generator = train_datagen.flow_from_directory(
    train_dir,
    target_size=(img_height, img_width),
    batch_size=batch_size,
    class_mode='binary'
)

# Load images from the validation set
validation_generator = validation_datagen.flow_from_directory(
    validation_dir,
    target_size=(img_height, img_width),
    batch_size=batch_size,
    class_mode='binary'
)

# Create a simple CNN model
model = tf.keras.Sequential([
    tf.keras.layers.Conv2D(32, (3, 3), activation='relu', input_shape=(img_height, img_width, 3)),
    tf.keras.layers.MaxPooling2D(2, 2),
    tf.keras.layers.Conv2D(64, (3, 3), activation='relu'),
    tf.keras.layers.MaxPooling2D(2, 2),
    tf.keras.layers.Conv2D(128, (3, 3), activation='relu'),
    tf.keras.layers.MaxPooling2D(2, 2),
    tf.keras.layers.Flatten(),
    tf.keras.layers.Dense(128, activation='relu'),
    tf.keras.layers.Dense(1, activation='sigmoid')
])

# Compile the model
model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])

# Train the model
model.fit(train_generator, epochs=10, validation_data=validation_generator)

def predict_bank_card(image, model, threshold=0.5):
    img = cv2.resize(image, (img_height, img_width))
    img = img.astype(np.float32) / 255.0
    img = np.expand_dims(img, axis=0)
    prediction = model.predict(img)
    return prediction[0][0] >= threshold

def find_bank_cards(input_folder, output_folder, model, limit=1):
    found_bank_cards = 0
    input_files = os.listdir(input_folder)
    next_progress_threshold = 10

    for index, file_name in enumerate(input_files):
        if found_bank_cards >= limit:
            break

        file_path = os.path.join(input_folder, file_name)
        image = cv2.imread(file_path)

        if predict_bank_card(image, model):
            output_path = os.path.join(output_folder, file_name)
            cv2.imwrite(output_path, image)
            found_bank_cards += 1
            print(f"Found bank card {found_bank_cards}, file name: {file_name}")

            if found_bank_cards >= limit:
                break

        # Calculate and display progress percentage every 10%
        progress = (index + 1) / len(input_files) * 100
        if progress >= next_progress_threshold:
            print(f"Progress: {progress:.2f}%")
            next_progress_threshold += 0.5

    return found_bank_cards

input_folder = 'Replace/with/input/folder'
output_folder = 'Replace/with/output/folder'
os.makedirs(output_folder, exist_ok=True)

found_bank_cards = find_bank_cards(input_folder, output_folder, model)
print(f"Found {found_bank_cards} bank card images. Check them at the following path:")
print(output_folder)

elapsed_time = time.time() - start_time
print(f"Elapsed time: {elapsed_time:.2f} seconds")




