import gpxpy
import folium
from folium.plugins import HeatMap
import math

# Extracting coordinates from GPX files
def get_coordinates_from_gpx(filename):
    with open(filename, 'r') as gpx_file:
        gpx = gpxpy.parse(gpx_file)
        return [(point.latitude, point.longitude) for point in gpx.waypoints]

# Calculate the most concentrated range area
def get_bounding_box(coordinates):
    min_lat = min(coord[0] for coord in coordinates)
    max_lat = max(coord[0] for coord in coordinates)
    min_lng = min(coord[1] for coord in coordinates)
    max_lng = max(coord[1] for coord in coordinates)
    return [(min_lat, min_lng), (max_lat, max_lng)]

# Generate a map and draw the area
def generate_map(coordinates, bounding_box, map_filename):
    center_lat = (bounding_box[0][0] + bounding_box[1][0]) / 2
    center_lng = (bounding_box[0][1] + bounding_box[1][1]) / 2

    m = folium.Map(location=[center_lat, center_lng], zoom_start=13)

    HeatMap(coordinates).add_to(m)

    folium.Rectangle(
        bounding_box,
        color='#ff7800',
        fill=True,
        fill_color='#ffff00',
        fill_opacity=0.2
    ).add_to(m)

    m.save(map_filename)

# Read coordinates from GPX file
coordinates = get_coordinates_from_gpx('Replace/with/GPX/file/folder')

# Calculate the most concentrated range area
bounding_box = get_bounding_box(coordinates)

# Generate a map and draw the area
generate_map(coordinates, bounding_box, 'output_map.html')







