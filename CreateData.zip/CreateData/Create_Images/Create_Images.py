import requests
import os

API_KEY = 'Replace API Key from http://www.pexels.com'
SEARCH_QUERIES = ['Replace with image category']
RESULTS_PER_PAGE = 40
NUM_PAGES = 200
OUTPUT_DIR = 'Path to the storage folder'

headers = {
    'Authorization': API_KEY
}

if not os.path.exists(OUTPUT_DIR):
    os.makedirs(OUTPUT_DIR)

for query in SEARCH_QUERIES:
    for page in range(1, NUM_PAGES + 1):
        url = f'https://api.pexels.com/v1/search?query={query}&per_page={RESULTS_PER_PAGE}&page={page}'
        response = requests.get(url, headers=headers)
        data = response.json()

        for photo in data['photos']:
            image_url = photo['src']['large']
            image_filename = os.path.join(OUTPUT_DIR, f"{query}_{photo['id']}.jpg")

            with requests.get(image_url, stream=True) as img_response:
                img_response.raise_for_status()
                with open(image_filename, 'wb') as f:
                    for chunk in img_response.iter_content(chunk_size=8192):
                        f.write(chunk)

        print(f'{query} - Page {page} images downloaded.')




