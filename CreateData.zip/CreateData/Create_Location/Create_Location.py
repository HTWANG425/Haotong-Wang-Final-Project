import gpxpy
import gpxpy.gpx
import random
import math

# Generate new geographic coordinates based on center point, distance and angle
def generate_coordinate(center_lat, center_lng, distance, angle):
    earth_radius = 6371  # Earth's radius in kilometers
    latitude_change = (distance * math.sin(math.radians(angle))) / earth_radius
    longitude_change = (distance * math.cos(math.radians(angle))) / (earth_radius * math.cos(math.radians(center_lat)))

    new_lat = center_lat + math.degrees(latitude_change)
    new_lng = center_lng + math.degrees(longitude_change)
    return new_lat, new_lng

# Generate random geolocation data
def generate_random_coordinates(center_lat, center_lng, num_points, max_distance):
    coordinates = []
    for i in range(num_points):
        distance = random.uniform(0, max_distance)
        angle = random.uniform(0, 360)
        coordinates.append(generate_coordinate(center_lat, center_lng, distance, angle))
    return coordinates

# Create GPX file
def generate_gpx(coordinates, filename):
    gpx = gpxpy.gpx.GPX()

    for lat, lng in coordinates:
        waypoint = gpxpy.gpx.GPXWaypoint(latitude=lat, longitude=lng)
        gpx.waypoints.append(waypoint)

    with open(filename, 'w') as gpx_file:
        gpx_file.write(gpx.to_xml())

# Center point coordinates, using Birmingham as an example
center_lat = 52.4788
center_lng = -1.8991

# Generate 1000 geolocation data close to the center point
close_coordinates = generate_random_coordinates(center_lat, center_lng, 1000, 0.5)

# Generate 1000 random geolocation data
random_coordinates = generate_random_coordinates(center_lat, center_lng, 1000, 5)

# Merge all geolocation data
all_coordinates = close_coordinates + random_coordinates

# Generate GPX file
generate_gpx(all_coordinates, 'output.gpx')






