import os
import openai
import random
from datetime import datetime, timedelta
import xml.etree.ElementTree as ET
from faker import Faker

fake = Faker("en_GB")

openai.api_key = "Replace/with/your/OpenAI/API/key"

def random_date(start_date, end_date):
    delta = end_date - start_date
    random_days = random.randrange(delta.days)
    random_seconds = random.randrange(86400)
    return start_date + timedelta(days=random_days, seconds=random_seconds)

def generate_message():
    topics = ["football", "weather"]
    selected_topic = random.choice(topics)

    prompt = (
        f"Generate a realistic and unique SMS message content "
        f"related to {selected_topic} in the UK between January and March 2023."
    )

    response = openai.Completion.create(
        engine="text-davinci-002",
        prompt=prompt,
        max_tokens=100,
        n=1,
        stop=None,
        temperature=0.8,
    )

    return response.choices[0].text.strip()

def generate_sms_xml(num_messages, output_file):
    root = ET.Element("sms_list")

    start_date = datetime(2023, 1, 1)
    end_date = datetime(2023, 3, 31)

    for i in range(num_messages):
        sms = ET.SubElement(root, "sms")

        date = random_date(start_date, end_date)
        sms.set("date", date.strftime("%Y-%m-%d %H:%M:%S"))
        sms.set("from", f"+4407{fake.random_int(min=100000000, max=999999999)}")
        sms.text = generate_message()

    tree = ET.ElementTree(root)
    tree.write(output_file, encoding="utf-8", xml_declaration=True)

if __name__ == "__main__":
    generate_sms_xml(1000, "sms_list.xml")




